# python3-django-inventory
An inventory management system, based on buckets you can place items in

# Installation
This is a python 3 django module and cannot be used standalone. Also needs `crispy_forms`, which on debianoid systems is available as `python3-django-crispy-forms`. Create a project, add the contents of this repositories as a directory named `inventory`.
